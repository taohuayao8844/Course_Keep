public class test1 {
    public static void main(String[] args) {
        int a = 8;
        int b = 10;
        int sum = a + b;
        System.out.println( a + "+" + b + "=" + sum);
    }
}